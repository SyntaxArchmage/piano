#!/usr/bin/env bash
# Setup tuna as a CLI tool.
# Run from anywhere: bash scripts/setup.sh
# After this, `tuna` is available on PATH.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'
pass() { echo -e "  ${GREEN}PASS${NC}  $*"; }
warn() { echo -e "  ${YELLOW}WARN${NC}  $*"; }
fail() { echo -e "  ${RED}FAIL${NC}  $*"; exit 1; }
step() { echo "  ...  $*"; }
ok() { echo -e "${GREEN}${BOLD}✓${NC}  $*"; }
require_node() { command -v node &>/dev/null || fail "node not found — install Node.js (https://nodejs.org)"; }

echo ""
echo "╔══════════════════════════════╗"
echo "║   tuna install               ║"
echo "╚══════════════════════════════╝"
echo ""

# ── 1. Prerequisites ────────────────────────────────────────────────────────

step "checking prerequisites"

require_node
pass "node $(node --version)"

if ! command -v npm &>/dev/null; then
  fail "npm not found"
fi
pass "npm $(npm --version)"

# ── 2. Install dependencies ─────────────────────────────────────────────────

step "npm install"
(cd "$REPO_ROOT" && npm install --silent)
pass "dependencies installed"

# ── 3. Link CLI globally ─────────────────────────────────────────────────────

step "linking tuna binary (npm link)"
(cd "$REPO_ROOT" && npm link --workspace @tuna/cli --silent)
pass "tuna linked"

# ── 4. Agent config ─────────────────────────────────────────────────────────

step "checking agent config"

CONFIG_FILE="$HOME/.tuna/agent.config.json"
CONFIG_TEMPLATE="$SCRIPT_DIR/agent.config.template.json"
if [[ -f "$CONFIG_FILE" ]]; then
  # An existing config carries the user's real credential. Installing over it
  # would destroy it, so the template is only ever placed when nothing is there.
  pass "kept existing config $CONFIG_FILE"
elif [[ ! -f "$CONFIG_TEMPLATE" ]]; then
  warn "config template not found at $CONFIG_TEMPLATE — skipped"
else
  mkdir -p "$(dirname "$CONFIG_FILE")"
  cp "$CONFIG_TEMPLATE" "$CONFIG_FILE"
  pass "created $CONFIG_FILE from template — replace apiKey CHANGE_ME before running"
fi

# ── 5. Verify tuna is on PATH ────────────────────────────────────────────────

TUNA_BIN="$(npm prefix -g)/bin/tuna"
if command -v tuna &>/dev/null; then
  pass "tuna found at $(command -v tuna)"
elif [[ -x "$TUNA_BIN" ]]; then
  warn "tuna installed at $TUNA_BIN but not on PATH"
  echo ""
  echo "  Add this to your shell profile (~/.bashrc, ~/.zshrc, etc.):"
  echo ""
  echo "    export PATH=\"$(npm prefix -g)/bin:\$PATH\""
  echo ""
  echo "  Then reload your shell or run:"
  echo ""
  echo "    source ~/.bashrc   # or ~/.zshrc"
  echo ""
else
  warn "tuna binary not found after linking — check npm global prefix is on PATH"
  echo "  npm global prefix: $(npm prefix -g)"
fi

echo ""
echo "════════════════════════════════"
ok "setup complete"
echo ""
echo "  Usage:"
echo "    tuna -p \"optimize gemm kernel\""
echo "    tuna doctor          # capability report (three-state per harness)"
echo ""
echo "  Dev mode: source edits under packages/**/src take effect immediately (tsx)."
