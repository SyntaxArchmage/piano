// The workflow-END contract, isolated: a scripted-harness workflow RESOLVES —
// and its progress ledger reports completed — exactly when its last worker
// has finished, for the three shapes the user hits: one worker, fan-out
// (multi worker), and a loop. Where the big suite pins per-shape mechanics
// (ordering, handoffs, iteration actors), these tests pin only the end: the
// effect settles, every planned worker ran exactly once, and progress.json
// lands at remainingStages: 0. A workflow that "never ends after all workers
// finish" fails here.
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { NodeFileSystem } from "@effect/platform-node";
import { Effect } from "effect";
import { describe, expect, it } from "vitest";
import { createSession, Logging, loggingService } from "../../packages/logging/src/index.js";
import { loadAndExecuteWorkflow } from "../../packages/orchestrator/src/index.js";
import type { AgentRequest } from "../../packages/harness/src/index.js";

const ONE_WORKER_WORKFLOW = `version: 3
workflow:
  name: end-single
  nodes:
    - stage:
        name: respond
        worker: basic
        from: []
`;

const FAN_OUT_WORKFLOW = `version: 3
workflow:
  name: end-fan-out
  nodes:
    - stage:
        name: left
        worker: basic
        from: []
    - stage:
        name: right
        worker: basic
        from: []
    - stage:
        name: joined
        worker: basic
        handoff: joined.json
        from: [left, right]
`;

const LOOP_WORKFLOW = `version: 3
workflow:
  name: end-loop
  nodes:
    - stage:
        name: seed
        worker: basic
        from: []
    - loop:
        name: tune
        from: [seed]
        entry: propose
        exit: report
        iterations: 3
        nodes:
          - stage:
              name: propose
              worker: basic
              handoff: seed.json
              validate: text-response
              from: []
          - stage:
              name: report
              worker: smoke-test-agent
              handoff: proposal.json
              from: [propose]
`;

function stageId(request: AgentRequest): string {
  const matched = /workflow stage `([^`]+)`/.exec(request.prompt);
  if (matched?.[1] === undefined) throw new Error(`missing workflow stage context: ${request.prompt}`);
  return matched[1];
}

function invocationId(request: AgentRequest): string {
  const matched = /workflow stage `[^`]+` \(([^)]+)\)/.exec(request.prompt);
  if (matched?.[1] === undefined) throw new Error(`missing workflow invocation context: ${request.prompt}`);
  return matched[1];
}

function validationPath(request: AgentRequest): string {
  const path = request.prompt.split("\n").find((line) => line.endsWith("/result.json"));
  if (path === undefined) throw new Error(`missing validation result path: ${request.prompt}`);
  return path;
}

async function testSession(root: string) {
  return await Effect.runPromise(
    createSession({ root, cwd: root, runsRoot: join(root, "runs") }).pipe(Effect.provide(NodeFileSystem.layer)),
  );
}

function runWorkflow<A>(session: Awaited<ReturnType<typeof testSession>>, effect: Effect.Effect<A, unknown, Logging | import("@effect/platform").FileSystem.FileSystem>): Promise<A> {
  return Effect.runPromise(effect.pipe(
    Effect.provideService(Logging, loggingService(session.log, session.trace)),
    Effect.provide(NodeFileSystem.layer),
  ));
}

/** The end-of-run ledger every shape must reach: completed, fully planned,
 * zero remaining. Read after the execution effect has ALREADY resolved — the
 * point of this suite is that resolution happens at all, then that it is
 * honest. */
async function readFinalProgress(runDir: string): Promise<Record<string, unknown>> {
  return JSON.parse(await readFile(join(runDir, "progress.json"), "utf8")) as Record<string, unknown>;
}

describe("workflow ends when its scripted workers finish", () => {
  it("resolves after the single worker, progress completed", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-end-single-"));
    try {
      await writeFile(join(root, "one.yml"), ONE_WORKER_WORKFLOW);
      const session = await testSession(root);
      const stages: string[] = [];
      const result = await runWorkflow(session, loadAndExecuteWorkflow({
        root, workflowPath: join(root, "one.yml"), runDir: session.runDir, executionId: "end-single", cwd: root, prompt: "answer",
        agentRunner: (request) => Effect.promise(async () => {
          stages.push(stageId(request));
          return {
            sessionId: "s1", transcriptPath: "/tmp/s1.jsonl", text: "done",
            continuation: { harness: "pi", sessionId: "s1", transcriptPath: "/tmp/s1.jsonl" },
          };
        }),
      }));
      expect(stages).toEqual(["respond"]);
      expect(result.stages.map((stage) => stage.id)).toEqual(["respond@root"]);
      expect(await readFinalProgress(session.runDir)).toMatchObject({
        status: "completed", plannedStages: 1, completedStages: 1, remainingStages: 0,
      });
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  }, 60_000);

  it("resolves only after every fan-out worker, progress completed", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-end-fanout-"));
    try {
      await writeFile(join(root, "fan.yml"), FAN_OUT_WORKFLOW);
      const session = await testSession(root);
      const stages: string[] = [];
      await runWorkflow(session, loadAndExecuteWorkflow({
        root, workflowPath: join(root, "fan.yml"), runDir: session.runDir, executionId: "end-fanout", cwd: root, prompt: "join",
        agentRunner: (request) => Effect.promise(async () => {
          const stage = stageId(request);
          stages.push(stage);
          // A visible delay keeps "resolves after ALL workers" honest: if the
          // engine settled on the first one, the joined turn and the count
          // below would fail.
          await new Promise((resolve) => setTimeout(resolve, 10));
          return {
            sessionId: `s-${stage}`, transcriptPath: `/tmp/${stage}.jsonl`, text: `${stage} out`,
            continuation: { harness: "pi", sessionId: `s-${stage}`, transcriptPath: `/tmp/${stage}.jsonl` },
          };
        }),
      }));
      expect(stages).toEqual(["left", "right", "joined"]);
      expect(await readFinalProgress(session.runDir)).toMatchObject({
        status: "completed", plannedStages: 3, completedStages: 3, remainingStages: 0,
      });
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  }, 60_000);

  it("resolves after the exact iteration count, progress completed", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-end-loop-"));
    try {
      await writeFile(join(root, "loop.yml"), LOOP_WORKFLOW);
      const session = await testSession(root);
      const stages: string[] = [];
      await runWorkflow(session, loadAndExecuteWorkflow({
        root, workflowPath: join(root, "loop.yml"), runDir: session.runDir, executionId: "end-loop", cwd: root, prompt: "iterate",
        agentRunner: (request) => Effect.promise(async () => {
          const stage = stageId(request);
          stages.push(stage);
          if (stage === "tune.propose") {
            const path = validationPath(request);
            await mkdir(dirname(path), { recursive: true });
            await writeFile(path, JSON.stringify({ text: invocationId(request) }));
          }
          return {
            sessionId: `s-${stages.length}`, transcriptPath: `/tmp/s-${stages.length}.jsonl`, text: `${stage} out`,
            continuation: { harness: "pi", sessionId: `s-${stages.length}`, transcriptPath: `/tmp/s-${stages.length}.jsonl` },
          };
        }),
      }));
      expect(stages).toEqual([
        "seed",
        "tune.propose", "tune.report",
        "tune.propose", "tune.report",
        "tune.propose", "tune.report",
      ]);
      expect(await readFinalProgress(session.runDir)).toMatchObject({
        status: "completed", plannedStages: 7, completedStages: 7, remainingStages: 0,
      });
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  }, 60_000);
});
