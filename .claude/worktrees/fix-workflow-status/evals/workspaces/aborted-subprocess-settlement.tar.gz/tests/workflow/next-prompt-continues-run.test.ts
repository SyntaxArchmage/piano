// The run's workflow execution is get-or-create, never re-created, across
// prompts: a second prompt on a finished run continues the same execution
// (same executionId) on the same resumed actor (same sessionId, turns 2) —
// the identical path /resume takes. This is the engine half of the TUI's
// queued-next-prompt behavior (tests/tui/prompt-queue.test.ts).
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { NodeFileSystem } from "@effect/platform-node";
import { Effect } from "effect";
import { describe, expect, it } from "vitest";
import { createSession, Logging, loggingService } from "../../packages/logging/src/index.js";
import {
  executeWorkflow,
  loadWorkflow,
  readWorkflowExecutionContinuation,
  type WorkflowSignoffRequest,
} from "../../packages/orchestrator/src/index.js";
import { executeAgent, type AgentRunner, type PiModule } from "../../packages/harness/src/index.js";

const SIGNOFF_WORKFLOW = `version: 3
workflow:
  name: basic-workflow
  nodes:
    - stage:
        name: agent
        worker: basic
        harness: pi
        tools: [read, bash, edit, write]
        from: []
        signoff: true
`;

function fakeSdk(): PiModule {
  const session = {
    sessionId: "workflow-session",
    sessionFile: "/tmp/workflow-session.jsonl",
    subscribe(listener: (event: unknown) => void): () => void {
      listener({ type: "message_update", assistantMessageEvent: { type: "text_delta", delta: "ans = " } });
      listener({ type: "message_end", message: { content: "answer" } });
      return () => undefined;
    },
    prompt: async () => undefined,
    abort: async () => undefined,
    dispose: () => undefined,
  };
  return {
    ModelRuntime: { create: async () => ({ getModel: () => ({ id: "model" }), setRuntimeApiKey: async () => undefined }) },
    SessionManager: { create: () => ({}), open: () => ({}) },
    SettingsManager: { inMemory: () => ({}) },
    DefaultResourceLoader: class {
      constructor(options: Record<string, unknown>) { void options; }
      reload = async () => undefined;
    },
    createAgentSession: async () => ({ session }),
  };
}

describe("a finished run's next prompt continues its workflow execution", () => {
  it("keeps the execution id and resumes the same actor, never creating a new one", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-next-prompt-continues-"));
    try {
      await writeFile(join(root, "workflow.yml"), SIGNOFF_WORKFLOW);
      const session = await Effect.runPromise(
        createSession({ root, cwd: root, runsRoot: join(root, "runs") }).pipe(Effect.provide(NodeFileSystem.layer)),
      );
      const runner: AgentRunner = (request, options) => executeAgent(request, { ...options, sdk: fakeSdk() });
      const signoff = (_request: WorkflowSignoffRequest) => Effect.succeed({ type: "approve" as const });
      // This mirrors the TUI's runPrompt: GET the run's execution first, pass it
      // to executeWorkflow, and only a first prompt (or a run with no
      // continuation) starts without one.
      const prompt = (text: string) =>
        Effect.runPromise(
          loadWorkflow(join(root, "workflow.yml"), root).pipe(
            Effect.flatMap((loaded) => readWorkflowExecutionContinuation(session.runDir, session.id).pipe(
              Effect.flatMap((execution) => executeWorkflow(loaded, {
                runDir: session.runDir,
                cwd: root,
                prompt: text,
                executionId: session.id,
                ...(execution === undefined ? {} : { execution }),
                signoff,
                agentRunner: runner,
              })),
            )),
            Effect.provideService(Logging, loggingService(session.log, session.trace)),
            Effect.provide(NodeFileSystem.layer),
          ),
        );
      const first = await prompt("first prompt");
      const continued = await Effect.runPromise(
        readWorkflowExecutionContinuation(session.runDir, session.id).pipe(Effect.provide(NodeFileSystem.layer)),
      );
      expect(continued).toBeDefined();
      const second = await prompt("second prompt");
      expect(second.text).toBeTruthy();
      // Same run = same execution; the actor was resumed, not re-created.
      expect(second.executionId).toBe(first.executionId);
      const after = await Effect.runPromise(
        readWorkflowExecutionContinuation(session.runDir, session.id).pipe(Effect.provide(NodeFileSystem.layer)),
      );
      expect(after?.promptIndex).toBe(2);
      const firstActor = continued?.actors.values().next().value;
      const secondActor = after?.actors.values().next().value;
      // Resumed the very same harness session: one actor, two turns.
      expect(firstActor?.continuation?.sessionId).toBeDefined();
      expect(secondActor?.continuation?.sessionId).toBe(firstActor?.continuation?.sessionId);
      expect(secondActor?.turns).toBeGreaterThanOrEqual(2);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });
});
