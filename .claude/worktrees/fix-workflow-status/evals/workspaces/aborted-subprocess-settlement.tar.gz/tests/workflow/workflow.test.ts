import { mkdir, mkdtemp, readdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { FileSystem } from "@effect/platform";
import { NodeFileSystem } from "@effect/platform-node";
import { Cause, Effect, Exit, Option } from "effect";
import { describe, expect, it, vi } from "vitest";
import {
  compileWorkflow,
  PI_WORKFLOW_HARNESS,
  defaultConfigPath,
  defaultWorkflowTemplatePath,
  loadWorkflow,
  loadDefaultWorkflow,
  setWorkflowSelection,
  resolveWorkerResources,
  parseWorkflow,
  scheduleWorkflow,
  WorkflowError,
  type WorkflowDocument,
} from "../../packages/orchestrator/src/index.js";
import { LogWriter, TraceWriter, Logging, loggingService } from "../../packages/logging/src/index.js";

const SOURCE = "/tmp/workflow.yaml";
/** The shipped dsh coding template (kept in sync with recipes/workflows/coding-dsh.yml). */
const codingWorkflowTemplatePath = fileURLToPath(
  new URL("../../recipes/workflows/coding-dsh.yml", import.meta.url),
);
const CODING_WORKFLOW = `version: 3
workflow:
  name: coding-dsh
  nodes:
    - stage:
        name: coding
        worker: basic
        harness: dsh
        model: gpt-5.6-luna
        thinkingLevel: max
        tools: [read, bash, edit, write, web_search]
        from: []
`;

/** The shipped claude coding template (kept in sync with recipes/workflows/coding-claude.yml). */
const codingClaudeWorkflowTemplatePath = fileURLToPath(
  new URL("../../recipes/workflows/coding-claude.yml", import.meta.url),
);
const CODING_CLAUDE_WORKFLOW = `version: 3
workflow:
  name: coding-claude
  nodes:
    - stage:
        name: coding
        worker: basic
        harness: claude
        model: gpt-5.6-luna
        thinkingLevel: max
        tools: [Read, Bash, Edit, Write, Glob, Grep, WebSearch]
        from: []
`;

const codingPiWorkflowTemplatePath = fileURLToPath(
  new URL("../../recipes/workflows/coding-pi.yml", import.meta.url),
);

const WEB_SEARCH_WORKFLOWS = [
  { path: fileURLToPath(new URL("../../recipes/workflows/web-search.yml", import.meta.url)), harness: "pi", tool: "web_search" },
  { path: fileURLToPath(new URL("../../recipes/workflows/web-search-dsh.yml", import.meta.url)), harness: "dsh", tool: "web_search" },
  { path: fileURLToPath(new URL("../../recipes/workflows/web-search-claude.yml", import.meta.url)), harness: "claude", tool: "WebSearch" },
] as const;

// A worker-bound workflow whose `worker: smoke-test-agent` resolves to a
// recipes/<worker>/ tree at the workspace root. The worker resources
// (system-prompt.md / agents.md / skills) are auto-discovered from that
// directory — the stage DSL itself carries no resource paths.
const SMOKE_WORKFLOW = `version: 3
workflow:
  name: prompt-response
  nodes:
    - stage:
        name: respond
        worker: smoke-test-agent
        from: []
        tools: []
`;

const VALIDATE_WORKFLOW = CODING_WORKFLOW.replace(
  "        from: []\n",
  "        validate: text-response\n        from: []\n",
);

function run<A, E>(effect: Effect.Effect<A, E, never>): Promise<Exit.Exit<A, E>> {
  return Effect.runPromiseExit(effect);
}

function runLogging<A, E>(effect: Effect.Effect<A, E, FileSystem.FileSystem | Logging>): Promise<Exit.Exit<A, E>> {
  const log = new LogWriter("test", join(tmpdir(), "tuna-workflow-log.jsonl"));
  const trace = new TraceWriter("test", join(tmpdir(), "tuna-workflow-trace.jsonl"));
  return run(effect.pipe(
    Effect.provideService(Logging, loggingService(log, trace)),
    Effect.provide(NodeFileSystem.layer),
  ));
}

function firstStage(document: WorkflowDocument) {
  const node = document.workflow.nodes[0];
  return node !== undefined && "stage" in node ? node.stage : undefined;
}

describe(" single-stage workflow", () => {
  it("parses, compiles, and schedules the latest DSL shape sequentially", async () => {
    await expect(readFile(codingWorkflowTemplatePath, "utf8")).resolves.toBe(CODING_WORKFLOW);
    const parsed = await run(parseWorkflow(CODING_WORKFLOW, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (!Exit.isSuccess(compiled)) return;
    const scheduled = await run(scheduleWorkflow(compiled.value));
    expect(Exit.isSuccess(scheduled)).toBe(true);
    if (Exit.isSuccess(scheduled)) {
      expect(scheduled.value.map((item) => item.stage.name)).toEqual(["coding"]);
      expect(scheduled.value[0]?.stage.worker).toBe("basic");
      expect(scheduled.value[0]?.stage.harness).toBe("dsh");
      expect(scheduled.value[0]?.stage.tools).toEqual(["read", "bash", "edit", "write", "web_search"]);
    }
  });

  it("ships the coding-claude template parsed against the claude tool catalog", async () => {
    await expect(readFile(codingClaudeWorkflowTemplatePath, "utf8")).resolves.toBe(CODING_CLAUDE_WORKFLOW);
    const parsed = await run(parseWorkflow(CODING_CLAUDE_WORKFLOW, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (!Exit.isSuccess(compiled)) return;
    const stage = compiled.value.stages[0]?.stage;
    expect(stage?.harness).toBe("claude");
    expect(stage?.tools).toEqual(["Read", "Bash", "Edit", "Write", "Glob", "Grep", "WebSearch"]);
  });

  it("ships coding-pi with web_search instead of the larger web_fetch surface", async () => {
    const source = await readFile(codingPiWorkflowTemplatePath, "utf8");
    const parsed = await run(parseWorkflow(source, codingPiWorkflowTemplatePath));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, codingPiWorkflowTemplatePath));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (!Exit.isSuccess(compiled)) return;
    const tools = compiled.value.stages[0]?.stage.tools ?? [];
    expect(tools).toContain("web_search");
    expect(tools).not.toContain("web_fetch");
  });

  it("ships one explicit web-search workflow for each supported native adapter", async () => {
    for (const workflow of WEB_SEARCH_WORKFLOWS) {
      const source = await readFile(workflow.path, "utf8");
      const parsed = await run(parseWorkflow(source, workflow.path));
      expect(Exit.isSuccess(parsed)).toBe(true);
      if (!Exit.isSuccess(parsed)) continue;
      const compiled = await run(compileWorkflow(parsed.value, workflow.path));
      expect(Exit.isSuccess(compiled)).toBe(true);
      if (!Exit.isSuccess(compiled)) continue;
      const stage = compiled.value.stages[0]?.stage;
      expect(stage?.harness).toBe(workflow.harness);
      expect(stage?.tools).toEqual([workflow.tool]);
    }
  });

  it("accepts additional stages and orders them by dependency at compile", async () => {
    const secondStage = SMOKE_WORKFLOW.replace(
      "        tools: []\n",
      "        tools: []\n    - stage:\n        name: second\n        worker: other\n        validate: text-response\n        from: [respond]\n",
    );
    const parsed = await run(parseWorkflow(secondStage, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (Exit.isSuccess(compiled)) {
      expect(compiled.value.stages.map((s) => s.stage.name)).toEqual(["respond", "second"]);
    }
  });

  it("rejects an unknown validator name at compile time", async () => {
    const source = VALIDATE_WORKFLOW.replace(
      "        validate: text-response\n",
      "        validate: no-such-validator\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isFailure(compiled)).toBe(true);
    if (Exit.isFailure(compiled)) {
      const failure = Cause.failureOption(compiled.cause);
      expect(Option.isSome(failure)).toBe(true);
      if (Option.isSome(failure)) {
        expect(failure.value).toBeInstanceOf(WorkflowError);
        expect(failure.value.message).toContain("no-such-validator");
      }
    }
  });

  it("uses pi as the canonical default harness", async () => {
    expect(PI_WORKFLOW_HARNESS).toBe("pi");
    const parsed = await run(parseWorkflow(SMOKE_WORKFLOW, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.harness).toBe("pi");
  });

  it("accepts an optional whole-stage timeout", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        from: []\n",
      "        from: []\n        timeout: 1800\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.timeout).toBe(1800);
  });

  it("rejects a non-positive stage timeout", async () => {
    for (const bad of ["0", "-5"]) {
      const source = SMOKE_WORKFLOW.replace(
        "        from: []\n",
        `        from: []\n        timeout: ${bad}\n`,
      );
      const parsed = await run(parseWorkflow(source, SOURCE));
      expect(Exit.isFailure(parsed)).toBe(true);
      if (Exit.isFailure(parsed)) {
        const failure = Cause.failureOption(parsed.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) {
          expect(failure.value).toBeInstanceOf(WorkflowError);
          expect(failure.value.message).toContain("stage.timeout");
        }
      }
    }
  });

  it("rejects an unsupported default harness value", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        from: []\n",
      "        from: []\n        harness: default\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isFailure(parsed)).toBe(true);
  });

  it("keeps an explicit pi harness canonical", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        from: []\n",
      "        from: []\n        harness: pi\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.harness).toBe("pi");
  });

  it("accepts the selectable subprocess harnesses at the workflow DSL boundary", async () => {
    for (const harness of ["pi-cli", "claude", "dsh"] as const) {
      const source = SMOKE_WORKFLOW.replace(
        "        from: []\n",
        `        from: []\n        harness: ${harness}\n`,
      );
      const parsed = await run(parseWorkflow(source, SOURCE));
      expect(Exit.isSuccess(parsed)).toBe(true);
      if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.harness).toBe(harness);
    }
  });

  it("accepts signoff as a stage boolean", async () => {
    for (const value of ["true", "false"]) {
      const source = SMOKE_WORKFLOW.replace(
        "        from: []\n",
        `        from: []\n        signoff: ${value}\n`,
      );
      const parsed = await run(parseWorkflow(source, SOURCE));
      expect(Exit.isSuccess(parsed)).toBe(true);
      if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.signoff).toBe(value === "true");
    }
  });

  it("omits signoff when the stage does not declare it", async () => {
    const parsed = await run(parseWorkflow(SMOKE_WORKFLOW, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (Exit.isSuccess(parsed)) expect(firstStage(parsed.value)?.signoff).toBeUndefined();
  });

  it("rejects a non-boolean stage signoff", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        from: []\n",
      "        from: []\n        signoff: \"ask\"\n",
    );
    expect(Exit.isFailure(await run(parseWorkflow(source, SOURCE)))).toBe(true);
  });

  it("accepts multiple tools as stage inputs", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        tools: []\n",
      "        tools:\n          - read\n          - bash\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    expect(firstStage(parsed.value)?.tools).toEqual(["read", "bash"]);
  });

  it("rejects empty or duplicate tool names", async () => {
    const duplicateTools = SMOKE_WORKFLOW.replace(
      "        tools: []\n",
      "        tools:\n          - read\n          - read\n",
    );
    expect(Exit.isFailure(await run(parseWorkflow(duplicateTools, SOURCE)))).toBe(true);
  });

  // Exact-native-name contract: a stage lists its harness's real tool ids;
  // adapters transport them verbatim. Wrong-cased or wrong-harness names are
  // rejected at parse time instead of being silently dropped by the CLI.
  describe("stage.tools exact-name validation", () => {
    const withTools = (harness: string, tools: string) => SMOKE_WORKFLOW
      .replace("        tools: []\n", `        harness: ${harness}\n        tools: ${tools}\n`);

    const parseFailureMessage = async (source: string): Promise<string> => {
      const parsed = await run(parseWorkflow(source, SOURCE));
      expect(Exit.isFailure(parsed)).toBe(true);
      if (!Exit.isFailure(parsed)) return "";
      const failure = Cause.failureOption(parsed.cause);
      expect(Option.isSome(failure)).toBe(true);
      return Option.isSome(failure) ? failure.value.message : "";
    };

    it("rejects a claude-native name on a pi stage", async () => {
      const message = await parseFailureMessage(withTools("pi", "[Read]"));
      expect(message).toContain('unknown tool "Read"');
      expect(message).toContain('harness "pi"');
    });

    it("rejects a pi-native name on a claude stage", async () => {
      const message = await parseFailureMessage(withTools("claude", "[read, bash, edit, write]"));
      expect(message).toContain('unknown tool "read"');
      expect(message).toContain('harness "claude"');
    });

    it("accepts claude native ids including scoped Bash patterns", async () => {
      const parsed = await run(parseWorkflow(
        withTools("claude", "[Read, Bash, Edit, Write, Bash(git *)]"),
        SOURCE,
      ));
      expect(Exit.isSuccess(parsed)).toBe(true);
      if (Exit.isSuccess(parsed)) {
        expect(firstStage(parsed.value)?.tools).toEqual(["Read", "Bash", "Edit", "Write", "Bash(git *)"]);
      }
    });

    it("accepts mcp server tool names on claude", async () => {
      const parsed = await run(parseWorkflow(withTools("claude", "[mcp__github__list_issues]"), SOURCE));
      expect(Exit.isSuccess(parsed)).toBe(true);
    });

    it("accepts the native dsh tool ids", async () => {
      const parsed = await run(parseWorkflow(
        withTools("dsh", "[read, bash, edit, write, ask_user_question, web_search]"),
        SOURCE,
      ));
      expect(Exit.isSuccess(parsed)).toBe(true);
    });

    it("rejects scoped patterns on harnesses without permission-rule syntax", async () => {
      const message = await parseFailureMessage(withTools("pi", "[read(*)]"));
      expect(message).toContain('unknown tool "read(*)"');
    });
  });

  it("requires a harness-exact write or exec tool on a validating claude stage", async () => {
    const validateStage = (tools: string) => VALIDATE_WORKFLOW
      .replace("        harness: dsh\n", "        harness: claude\n")
      .replace("        tools: [read, bash, edit, write, web_search]\n", `        tools: ${tools}\n`);

    const withoutExec = await run(parseWorkflow(validateStage("[Read, Edit]"), SOURCE));
    expect(Exit.isSuccess(withoutExec)).toBe(true);
    if (Exit.isSuccess(withoutExec)) {
      const compiled = await run(compileWorkflow(withoutExec.value, SOURCE));
      expect(Exit.isFailure(compiled)).toBe(true);
      if (Exit.isFailure(compiled)) {
        const failure = Cause.failureOption(compiled.cause);
        expect(Option.isSome(failure) ? failure.value.message : "").toContain("must allow write or bash");
      }
    }

    // Scoped Bash still grants exec capability.
    const scopedExec = await run(parseWorkflow(validateStage("[Read, Bash(git *)]"), SOURCE));
    expect(Exit.isSuccess(scopedExec)).toBe(true);
    if (Exit.isSuccess(scopedExec)) {
      expect(Exit.isSuccess(await run(compileWorkflow(scopedExec.value, SOURCE)))).toBe(true);
    }
  });

  it("rejects a validation stage that cannot write its result", async () => {
    const source = VALIDATE_WORKFLOW.replace(
      "        tools: [read, bash, edit, write, web_search]\n",
      "        tools: []\n",
    );
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isFailure(compiled)).toBe(true);
    if (!Exit.isFailure(compiled)) return;
    const failure = Cause.failureOption(compiled.cause);
    expect(Option.isSome(failure)).toBe(true);
    if (Option.isSome(failure)) expect(failure.value.message).toContain("must allow write or bash");
  });

  it("rejects a stage that declares a removed resource field", async () => {
    const source = SMOKE_WORKFLOW.replace(
      "        tools: []\n",
      "        tools: []\n        system_prompt: recipes/system-prompt.md\n",
    );
    expect(Exit.isFailure(await run(parseWorkflow(source, SOURCE)))).toBe(true);
  });

  it("rejects the renamed contract field with an actionable migration error", async () => {
    const source = CODING_WORKFLOW.replace("        from: []\n", "        contract: text-response\n        from: []\n");
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isFailure(parsed)).toBe(true);
    if (!Exit.isFailure(parsed)) return;
    const failure = Cause.failureOption(parsed.cause);
    expect(Option.isSome(failure)).toBe(true);
    if (Option.isSome(failure)) expect(failure.value.message).toContain("renamed to stage.validate");
  });

  it("rejects validate:false instead of creating a second no-validation spelling", async () => {
    const source = CODING_WORKFLOW.replace("        from: []\n", "        validate: false\n        from: []\n");
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isFailure(parsed)).toBe(true);
    if (!Exit.isFailure(parsed)) return;
    const failure = Cause.failureOption(parsed.cause);
    expect(Option.isSome(failure)).toBe(true);
    if (Option.isSome(failure)) expect(failure.value.message).toContain("true or omitted");
  });

  it("rejects an unsafe handoff path before dispatch", async () => {
    const source = CODING_WORKFLOW.replace("        from: []\n", "        handoff: ../outside.json\n        from: []\n");
    expect(Exit.isFailure(await run(parseWorkflow(source, SOURCE)))).toBe(true);
  });

  it("creates config.json naming the shipped default when no record exists", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-"));
    try {
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(defaultWorkflowTemplatePath);
        expect(result.value.document.workflow.name).toBe("topsop-tuning");
      }
      // The record file is created naming the exact shipped default; a
      // workflow.yml copy never happens.
      await expect(readdir(root)).resolves.toEqual([defaultConfigPath]);
      const config = JSON.parse(
        await readFile(join(root, defaultConfigPath), "utf8"),
      ) as Record<string, unknown>;
      expect(config.workflow).toBe("builtin:topsop-tuning");
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("loads the workflow recorded as the user selection in config.json", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-selected-"));
    try {
      const selectedPath = join(root, "selected.yml");
      await writeFile(selectedPath, CODING_WORKFLOW);
      await writeFile(
        join(root, defaultConfigPath),
        JSON.stringify({ harness: "pi", workflow: selectedPath }),
      );
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(selectedPath);
        expect(result.value.document.workflow.name).toBe("coding-dsh");
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("falls back to the builtin default when config.json is malformed", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-badconfig-"));
    try {
      await writeFile(join(root, defaultConfigPath), "{ not json {{{");
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(defaultWorkflowTemplatePath);
      }
      // A broken config is never rewritten behind the user's back.
      await expect(readFile(join(root, defaultConfigPath), "utf8")).resolves.toBe("{ not json {{{");
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("backfills the builtin workflow key into a legacy config.json", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-legacyconfig-"));
    try {
      // A config written before the record existed: the missing key is not a
      // failure — the key is added, naming the current default exactly.
      await writeFile(join(root, defaultConfigPath), JSON.stringify({ harness: "pi", agents: 1 }));
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(defaultWorkflowTemplatePath);
      }
      const config = JSON.parse(
        await readFile(join(root, defaultConfigPath), "utf8"),
      ) as Record<string, unknown>;
      expect(config.workflow).toBe("builtin:topsop-tuning");
      expect(config.harness).toBe("pi");
      expect(config.agents).toBe(1);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("loads the shipped default from a named builtin record", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-builtin-record-"));
    try {
      await writeFile(
        join(root, defaultConfigPath),
        JSON.stringify({ workflow: "builtin:topsop-tuning" }),
      );
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(defaultWorkflowTemplatePath);
      }
      // Already recorded: the config is left exactly as it was.
      await expect(readFile(join(root, defaultConfigPath), "utf8")).resolves.toBe(
        JSON.stringify({ workflow: "builtin:topsop-tuning" }),
      );
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("resolves any builtin template by exact name", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-builtin-named-"));
    try {
      await writeFile(join(root, defaultConfigPath), JSON.stringify({ workflow: "builtin:coding-dsh" }));
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(codingWorkflowTemplatePath);
        expect(result.value.document.workflow.name).toBe("coding-dsh");
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("renames the old unnamed builtin record to the current default", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-builtin-unnamed-"));
    try {
      // An unnamed "builtin" is ambiguous (the builtin set is multiple), so it
      // is rewritten to name the current default — never a load failure.
      await writeFile(join(root, defaultConfigPath), JSON.stringify({ workflow: "builtin" }));
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect(result.value.workflowPath).toBe(defaultWorkflowTemplatePath);
      }
      const config = JSON.parse(
        await readFile(join(root, defaultConfigPath), "utf8"),
      ) as Record<string, unknown>;
      expect(config.workflow).toBe("builtin:topsop-tuning");
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("reports a clear load failure when the recorded selection is missing", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-gone-"));
    try {
      await writeFile(
        join(root, defaultConfigPath),
        JSON.stringify({ workflow: join(root, "deleted.yml") }),
      );
      const result = await runLogging(loadDefaultWorkflow(root, process.cwd()));
      expect(Exit.isFailure(result)).toBe(true);
      if (Exit.isFailure(result)) {
        const failure = Cause.failureOption(result.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) expect(failure.value.message).toContain("deleted.yml");
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("records a selection in config.json preserving the other config keys", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-record-"));
    try {
      await writeFile(join(root, defaultConfigPath), JSON.stringify({ harness: "pi", agents: 2 }));
      const written = await runLogging(setWorkflowSelection(root, "/opt/selected.yml"));
      expect(Exit.isSuccess(written)).toBe(true);
      const config = JSON.parse(
        await readFile(join(root, defaultConfigPath), "utf8"),
      ) as Record<string, unknown>;
      expect(config.workflow).toBe("/opt/selected.yml");
      expect(config.harness).toBe("pi");
      expect(config.agents).toBe(2);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("refuses to overwrite an unparseable config.json with a selection", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-record-bad-"));
    try {
      await writeFile(join(root, defaultConfigPath), "{ broken");
      const written = await runLogging(setWorkflowSelection(root, "/opt/selected.yml"));
      expect(Exit.isFailure(written)).toBe(true);
      // The user's file is left exactly as it was.
      await expect(readFile(join(root, defaultConfigPath), "utf8")).resolves.toBe("{ broken");
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("discovers worker resources from the recipes tree for an explicit workflow", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-assets-"));
    try {
      const workflowPath = join(root, "special.yml");
      const workflow = SMOKE_WORKFLOW.replace(
        "        tools: []\n",
        "        tools:\n          - read\n",
      );
      await writeFile(workflowPath, workflow);
      const workerDir = join(root, "recipes", "smoke-test-agent");
      await mkdir(join(workerDir, "skills", "smoke-test-agent"), { recursive: true });
      await writeFile(join(workerDir, "system-prompt.md"), "system\n");
      await writeFile(join(workerDir, "agents.md"), "test context\n");
      await writeFile(
        join(workerDir, "skills", "smoke-test-agent", "SKILL.md"),
        "---\nname: smoke-test-agent\ndescription: test skill\n---\n",
      );
      const result = await runLogging(resolveWorkerResources("smoke-test-agent", root, workflowPath, "pi"));
      expect(Exit.isSuccess(result)).toBe(true);
      if (!Exit.isSuccess(result)) return;
      expect(result.value.systemPromptPath).toBe(join(workerDir, "system-prompt.md"));
      expect(result.value.contextFilePaths).toEqual([join(workerDir, "agents.md")]);
      expect(result.value.skillPaths).toEqual([join(workerDir, "skills", "smoke-test-agent")]);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("appends only the stage harness's agents.<harness>.md after the shared agents.md", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-harness-appendix-"));
    try {
      const workflowPath = join(root, "appendix.yml");
      await writeFile(workflowPath, SMOKE_WORKFLOW);
      const workerDir = join(root, "recipes", "smoke-test-agent");
      await mkdir(workerDir, { recursive: true });
      await writeFile(join(workerDir, "agents.md"), "shared\n");
      await writeFile(join(workerDir, "agents.pi.md"), "pi-only rules\n");
      await writeFile(join(workerDir, "agents.claude.md"), "claude-only rules\n");

      const piStage = await runLogging(resolveWorkerResources("smoke-test-agent", root, workflowPath, "pi"));
      expect(Exit.isSuccess(piStage)).toBe(true);
      if (Exit.isSuccess(piStage)) {
        expect(piStage.value.contextFilePaths).toEqual([
          join(workerDir, "agents.md"),
          join(workerDir, "agents.pi.md"),
        ]);
      }

      const claudeStage = await runLogging(resolveWorkerResources("smoke-test-agent", root, workflowPath, "claude"));
      expect(Exit.isSuccess(claudeStage)).toBe(true);
      if (Exit.isSuccess(claudeStage)) {
        expect(claudeStage.value.contextFilePaths).toEqual([
          join(workerDir, "agents.md"),
          join(workerDir, "agents.claude.md"),
        ]);
      }

      // A harness with no appendix keeps just the shared context file.
      const dshStage = await runLogging(resolveWorkerResources("smoke-test-agent", root, workflowPath, "dsh"));
      expect(Exit.isSuccess(dshStage)).toBe(true);
      if (Exit.isSuccess(dshStage)) {
        expect(dshStage.value.contextFilePaths).toEqual([join(workerDir, "agents.md")]);
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("rejects an agents.<harness>.md file with an unknown harness suffix at load", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-unknown-appendix-"));
    try {
      const workflowPath = join(root, "unknown.yml");
      await writeFile(workflowPath, SMOKE_WORKFLOW);
      const workerDir = join(root, "recipes", "smoke-test-agent");
      await mkdir(workerDir, { recursive: true });
      await writeFile(join(workerDir, "agents.md"), "shared\n");
      await writeFile(join(workerDir, "agents.gpt.md"), "mystery rules\n");

      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isFailure(result)).toBe(true);
      if (Exit.isFailure(result)) {
        const failure = Cause.failureOption(result.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) {
          expect(failure.value).toBeInstanceOf(WorkflowError);
          expect(failure.value.message).toContain("agents.gpt.md");
          expect(failure.value.message).toContain("pi, pi-cli, claude, dsh");
        }
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("discovers skills whose frontmatter uses CRLF line endings", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-crlf-skill-"));
    try {
      const workflowPath = join(root, "crlf.yml");
      await writeFile(workflowPath, SMOKE_WORKFLOW);
      const skillDir = join(root, "recipes", "smoke-test-agent", "skills", "smoke-test-agent");
      await mkdir(skillDir, { recursive: true });
      await writeFile(
        join(skillDir, "SKILL.md"),
        "---\r\nname: smoke-test-agent\r\ndescription: test skill\r\n---\r\n",
      );

      const result = await runLogging(resolveWorkerResources("smoke-test-agent", root, workflowPath, "pi"));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) expect(result.value.skillPaths).toEqual([skillDir]);
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("fails the load when the worker has no recipes directory", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-missing-worker-"));
    try {
      const workflowPath = join(root, "missing.yml");
      await writeFile(workflowPath, SMOKE_WORKFLOW);
      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isFailure(result)).toBe(true);
      if (Exit.isFailure(result)) {
        const failure = Cause.failureOption(result.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) {
          expect(failure.value).toBeInstanceOf(WorkflowError);
          expect(failure.value.message).toContain("smoke-test-agent");
        }
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("rejects worker values that are not plugin directory names", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-unsafe-worker-"));
    try {
      const workflowPath = join(root, "unsafe.yml");
      await writeFile(workflowPath, CODING_WORKFLOW.replace("worker: basic", "worker: ."));
      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isFailure(result)).toBe(true);
      if (Exit.isFailure(result)) {
        const failure = Cause.failureOption(result.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) expect(failure.value.message).toContain("plugin directory");
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("fails the load when a skill directory has no valid SKILL.md", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-bad-skill-"));
    try {
      const workflowPath = join(root, "bad-skill.yml");
      await writeFile(workflowPath, SMOKE_WORKFLOW);
      await mkdir(join(root, "recipes/smoke-test-agent/skills/broken"), { recursive: true });
      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isFailure(result)).toBe(true);
      if (Exit.isFailure(result)) {
        const failure = Cause.failureOption(result.cause);
        expect(Option.isSome(failure)).toBe(true);
        if (Option.isSome(failure)) {
          expect(failure.value).toBeInstanceOf(WorkflowError);
          expect(failure.value.message).toContain("SKILL.md");
        }
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("resolves validate:true from the worker-owned contract", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-worker-contract-"));
    try {
      const workflowPath = join(root, "contract.yml");
      const workerDir = join(root, "recipes", "custom-worker");
      await mkdir(workerDir, { recursive: true });
      await writeFile(workflowPath, CODING_WORKFLOW
        .replace("worker: basic", "worker: custom-worker")
        .replace("        from: []", "        validate: true\n        from: []"));
      await writeFile(join(workerDir, "contract.json"), JSON.stringify({
        version: 1,
        id: "custom-result",
        schema: {
          $schema: "https://json-schema.org/draft/2020-12/schema",
          type: "object",
          required: ["value"],
          properties: { value: { type: "string" } },
          additionalProperties: false,
        },
        example: { value: "ok" },
        outputs: { metrics: [] },
      }));

      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect([...result.value.workerResources!.values()][0]?.contract?.manifest.id).toBe("custom-result");
        expect(result.value.recipeRepositoryRoot).toBe(root);
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it("emits a user-visible deprecation warning for string-valued validation", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-legacy-warning-"));
    const emitWarning = vi.spyOn(process, "emitWarning").mockImplementation(() => {});
    try {
      const workflowPath = join(root, "legacy.yml");
      await writeFile(workflowPath, VALIDATE_WORKFLOW);

      const result = await runLogging(loadWorkflow(workflowPath, root, process.cwd()));

      expect(Exit.isSuccess(result)).toBe(true);
      expect(emitWarning).toHaveBeenCalledOnce();
      expect(emitWarning).toHaveBeenCalledWith(
        expect.stringContaining('stage "coding" (text-response)'),
        {
          code: "TUNA_LEGACY_WORKER_CONTRACT",
          type: "DeprecationWarning",
        },
      );
    } finally {
      emitWarning.mockRestore();
      await rm(root, { recursive: true, force: true });
    }
  });

  it("fails workflow loading when validate:true has no usable worker contract", async () => {
    for (const contractSource of [undefined, "{not-json"] as const) {
      const root = await mkdtemp(join(tmpdir(), "tuna-workflow-invalid-contract-"));
      try {
        const workflowPath = join(root, "contract.yml");
        const workerDir = join(root, "recipes", "custom-worker");
        await mkdir(workerDir, { recursive: true });
        await writeFile(workflowPath, CODING_WORKFLOW
          .replace("worker: basic", "worker: custom-worker")
          .replace("        from: []", "        validate: true\n        from: []"));
        if (contractSource !== undefined) await writeFile(join(workerDir, "contract.json"), contractSource);

        const result = await runLogging(loadWorkflow(workflowPath, root, root));
        expect(Exit.isFailure(result)).toBe(true);
        if (Exit.isFailure(result)) {
          const failure = Cause.failureOption(result.cause);
          expect(Option.isSome(failure)).toBe(true);
          if (Option.isSome(failure)) expect(failure.value.message).toContain("contract");
        }
      } finally {
        await rm(root, { recursive: true, force: true });
      }
    }
  });

  it("ignores an unused worker contract when validation is omitted", async () => {
    const root = await mkdtemp(join(tmpdir(), "tuna-workflow-unused-contract-"));
    try {
      const workflowPath = join(root, "contract.yml");
      const workerDir = join(root, "recipes", "custom-worker");
      await mkdir(workerDir, { recursive: true });
      await writeFile(workflowPath, CODING_WORKFLOW.replace("worker: basic", "worker: custom-worker"));
      await writeFile(join(workerDir, "contract.json"), "{not-json");

      const result = await runLogging(loadWorkflow(workflowPath, root, root));
      expect(Exit.isSuccess(result)).toBe(true);
      if (Exit.isSuccess(result)) {
        expect([...result.value.workerResources!.values()][0]?.contract).toBeUndefined();
      }
    } finally {
      await rm(root, { recursive: true, force: true });
    }
  });

  it.each([
    ["CUDA", "gpu-cuda-tuning.yml", "cuda-round-result-v2"],
    ["Triton", "gpu-triton-tuning.yml", "triton-round-result"],
  ] as const)("discovers every worker-owned contract in the built-in %s workflow", async (_family, file, roundContractId) => {
    const repositoryRoot = process.cwd();
    const workflowPath = join(repositoryRoot, "recipes", "workflows", file);
    const result = await runLogging(loadWorkflow(workflowPath, repositoryRoot, repositoryRoot));

    expect(Exit.isSuccess(result)).toBe(true);
    if (!Exit.isSuccess(result)) return;
    const contracts = [...result.value.workerResources!.values()].map((resources) => resources.contract?.manifest.id);
    expect(contracts).toHaveLength(6);
    expect(contracts.every((id) => id !== undefined)).toBe(true);
    expect(contracts).toContain(roundContractId);
  });

  it("binds the canonical topsop workflow to one contract per stage while legacy workers remain loadable", async () => {
    const repositoryRoot = process.cwd();
    const workflowPath = join(repositoryRoot, "recipes", "workflows", "topsop-tuning.yml");
    const result = await runLogging(loadWorkflow(workflowPath, repositoryRoot, repositoryRoot));

    expect(Exit.isSuccess(result)).toBe(true);
    if (!Exit.isSuccess(result)) return;
    const contracts = [...result.value.workerResources!.values()]
      .map((resources) => resources.contract?.manifest.id)
      .filter((id): id is string => id !== undefined);
    expect(contracts).toEqual([
      "topsop-env-report",
      "topsop-explore-report",
      "topsop-theory-report",
      "topsop-profile-report",
      "optimization-proposal",
      "topsop-implementation-report",
      "verification-report",
      "topsop-round-result",
      "summary-report",
    ]);

    for (const worker of ["topsop-estimate", "topsop-optimize", "topsop-verify"]) {
      const legacy = await runLogging(resolveWorkerResources(worker, repositoryRoot, workflowPath, "pi", { loadContract: true }));
      expect(Exit.isSuccess(legacy)).toBe(true);
      if (Exit.isSuccess(legacy)) expect(legacy.value.contract).toBeDefined();
    }
  });

  it("keeps the workflow error as a typed Effect failure", async () => {
    const parsed = await run(parseWorkflow("version: 2\n", SOURCE));
    expect(Exit.isFailure(parsed)).toBe(true);
    if (Exit.isFailure(parsed)) {
      const failure = parsed.cause as unknown;
      expect(failure).toBeDefined();
    }
    expect(new WorkflowError({ phase: "parse", path: SOURCE, message: "bad" }).phase).toBe("parse");
  });
});

describe("workflow autoCommit (ISSUE-017)", () => {
  const WITH_AUTO_COMMIT = CODING_WORKFLOW.replace("  name: coding-dsh\n", "  name: coding-dsh\n  autoCommit: true\n");

  it("parses autoCommit: true and threads it through compile", async () => {
    const parsed = await run(parseWorkflow(WITH_AUTO_COMMIT, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    expect(parsed.value.workflow.autoCommit).toBe(true);
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (Exit.isSuccess(compiled)) expect(compiled.value.autoCommit).toBe(true);
  });

  it("parses autoCommit: false", async () => {
    const source = CODING_WORKFLOW.replace("  name: coding-dsh\n", "  name: coding-dsh\n  autoCommit: false\n");
    const parsed = await run(parseWorkflow(source, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (Exit.isSuccess(parsed)) expect(parsed.value.workflow.autoCommit).toBe(false);
  });

  it("defaults autoCommit to false when omitted (opt-in)", async () => {
    const parsed = await run(parseWorkflow(CODING_WORKFLOW, SOURCE));
    expect(Exit.isSuccess(parsed)).toBe(true);
    if (!Exit.isSuccess(parsed)) return;
    expect(parsed.value.workflow.autoCommit).toBe(false);
    const compiled = await run(compileWorkflow(parsed.value, SOURCE));
    expect(Exit.isSuccess(compiled)).toBe(true);
    if (Exit.isSuccess(compiled)) expect(compiled.value.autoCommit).toBe(false);
  });

  it("rejects a non-boolean autoCommit value", async () => {
    const source = CODING_WORKFLOW.replace("  name: coding-dsh\n", "  name: coding-dsh\n  autoCommit: yes\n");
    expect(Exit.isFailure(await run(parseWorkflow(source, SOURCE)))).toBe(true);
  });

  it("still rejects unknown workflow-level fields next to autoCommit", async () => {
    const source = CODING_WORKFLOW.replace("  name: coding-dsh\n", "  name: coding-dsh\n  autoCommit: true\n  push: true\n");
    expect(Exit.isFailure(await run(parseWorkflow(source, SOURCE)))).toBe(true);
  });
});
