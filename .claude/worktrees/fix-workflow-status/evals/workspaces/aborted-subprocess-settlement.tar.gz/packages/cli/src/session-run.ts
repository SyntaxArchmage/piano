// One live session's replay loop: turns a prompt/TUI event into a workflow run
// and persists the trajectory, writing the headless result to stdout when a
// prompt was supplied. Extracted from main.ts so both the default entrypoint
// and `resume` can drive the same loop without a circular import.

import { NodeFileSystem } from "@effect/platform-node";
import { Effect, Exit } from "effect";
import { stderr, stdout } from "node:process";
import { dirname, join } from "node:path";
import {
  createSession,
  failureDetails,
  isCancellation,
  Logging,
  loggingService,
  logger,
  TRACE,
  type LoggingError,
  type LoggingService,
  type Session,
  type SessionError,
  type Source,
  type StagingSession,
  type TrajectoryWriteInput,
} from "@tuna/logging";
import {
  compileWorkflow,
  builtinWorkflowSelection,
  executeWorkflow,
  loadDefaultWorkflow,
  loadWorkflow,
  readWorkflowExecutionContinuation,
  setWorkflowSelection,
  type LoadedWorkflow,
  type WorkflowExecutionError,
  WorkflowError,
  type WorkflowSignoffDecision,
  type WorkflowSignoffRequest,
} from "@tuna/orchestrator";
import {
  createSteeringChannel,
  executeAgent,
  prepareHarnessHomes,
  type AgentContinuation,
  type AgentEvent,
  type AgentHarnessOptions,
  type AgentRunner,
  type SteeringChannel,
  HarnessHomeError,
} from "@tuna/harness";
import type { Terminal } from "@earendil-works/pi-tui";
import { runTui, type TuiResumeResult } from "./tui.js";
import { headlessSignoffChannel } from "./signoff.js";
import { sideAgentRequest } from "./side-agent.js";
import {
  agentEventLine,
  completedLine,
  failedLine,
  serializeLine,
  startedLine,
} from "./headless-json.js";
import type { CliError } from "./errors.js";
import { readResumeContext } from "./session-resume.js";
import { armStalledExitGuard } from "./stalled-exit.js";
import type { WorkflowGraphDefinition } from "./workflow-graph.js";

const SESSION_SOURCE: Source = { module: "cli", file: "session-run.ts", function: "runSession" };
const TUI_SOURCE: Source = { module: "cli", file: "tui.ts", function: "runTui" };
const INPUT_SOURCE: Source = { module: "cli", file: "session-run.ts", function: "runPrompt" };
const SESSION_LOG = logger(SESSION_SOURCE, { namespace: "cli" });
const TUI_LOG = logger(TUI_SOURCE, { namespace: "cli" });
const INPUT_LOG = logger(INPUT_SOURCE, { namespace: "cli" });

export type SessionRunError = CliError | LoggingError | WorkflowExecutionError | HarnessHomeError;

export interface SessionRunOptions {
  readonly workflowPath?: string;
  readonly prompt?: string;
  readonly json?: boolean;
  /** Resume this run as soon as the TUI opens. When it is the session's own run,
   * the takeover reuses the open session instead of opening a second one. */
  readonly resumeRunId?: string;
  /** Open the resume picker as soon as the TUI opens. */
  readonly resumePicker?: boolean;
  /** Mission-scoped native harness environment. The parent process never
   * mutates its own Claude/dsh configuration. */
  readonly agentOptions?: AgentHarnessOptions;
  /** Inject the harness agent adapter (tests) — production uses the real
   * executeAgent/configured adapter. Deterministic session tests mock "sending
   * the prompt" here while the real engine, session loop and TUI run. */
  readonly agentRunner?: AgentRunner;
  /** Drive the interactive TUI on an injected terminal (tests) instead of the
   * process terminal, so a scripted terminal can type into a real session. */
  readonly terminal?: Terminal;
}

/** Compile a loaded workflow into the read-only shape the status footer draws.
 * Shared by startup, `/workflow`, and `/resume`, which all change what the
 * footer should be tracking. */
function graphOf(workflow: LoadedWorkflow) {
  return compileWorkflow(workflow.document, workflow.workflowPath).pipe(
    Effect.map((compiled): WorkflowGraphDefinition => ({
      name: compiled.name,
      path: workflow.workflowPath,
      stages: compiled.stages.map((stage) => ({
        id: stage.id,
        dependsOn: stage.dependsOn,
        model: stage.stage.model,
      })),
      maps: compiled.regions
        .filter((region) => region.kind === "map" && region.count !== undefined)
        .map((region) => ({
          id: region.id,
          entryStageId: region.entryStageId,
          exitStageId: region.exitStageId,
          count: region.count ?? 0,
        })),
    })),
  );
}

/** Turn a live logging session into a replay loop: run the headless prompt or
 * open the TUI, and persist each completed prompt's trajectory. */
function runSessionBody(
  session: Session | StagingSession,
  options: SessionRunOptions,
): Effect.Effect<void, SessionRunError, import("@effect/platform").FileSystem.FileSystem> {
  const logging = loggingService(session.log, session.trace);
  // A staging session materialises its run directory at the first prompt; a
  // non-staging session already has one. Both reach the same `runPrompt` path.
  const commitSession = "commit" in session
    ? (prompt: string) => session.commit().pipe(
      Effect.tap(() => SESSION_LOG.info("run.created", {
        data: { runDir: session.runDir, promptLength: prompt.length },
      })),
      Effect.mapError((error) => error as SessionError),
    )
    : undefined;
  return Effect.gen(function* () {
    const initialWorkflow = yield* TRACE(
      options.workflowPath === undefined
        ? { module: "orchestrator", file: "workflow-file.ts", function: "loadDefaultWorkflow" }
        : { module: "orchestrator", file: "workflow-file.ts", function: "loadWorkflow" },
      options.workflowPath === undefined
        ? loadDefaultWorkflow(session.root)
        : loadWorkflow(options.workflowPath, session.root),
      {
        root: session.root,
        ...(options.workflowPath === undefined ? {} : { workflowPath: options.workflowPath }),
      },
    ).pipe(Effect.either);
    // An explicit workflow path is an assertion by the caller. Do not open a
    // generic TUI when that file is missing or malformed: the empty shell
    // hides the actionable load error and makes the requested workflow appear
    // to have been ignored.
    if (options.workflowPath !== undefined && initialWorkflow._tag === "Left") {
      return yield* Effect.fail(initialWorkflow.left);
    }
    let loadedWorkflow = initialWorkflow._tag === "Right" ? initialWorkflow.right : undefined;
    const initialWorkflowFailure = initialWorkflow._tag === "Left" ? initialWorkflow.left : undefined;
    let activeController: AbortController | undefined;
    /** The live prompt's steering channel; the TUI pushes mid-turn messages
     * through `steerActive` while it is set. Cleared with the prompt, like the
     * controller. */
    let activeSteering: SteeringChannel | undefined;
    let activeCwd = session.cwd;
    // The run this loop currently writes to. `/resume` swaps it in place, so
    // every prompt-scoped write (trajectory, log, trace, run directory) must be
    // read from here rather than captured from the outer `session`.
    let active: {
      session: Session;
      logging: LoggingService;
      /** Present only while the session is still staging. */
      commit?: (prompt: string) => Effect.Effect<void, SessionError, import("@effect/platform").FileSystem.FileSystem | Logging>;
    } = { session, logging, ...(commitSession === undefined ? {} : { commit: commitSession }) };
    const runsRoot = dirname(session.runDir);
    yield* TRACE(SESSION_SOURCE, Effect.gen(function* () {
      yield* SESSION_LOG.info("cli.started", {
        data: {
          command: "tuna",
          ...(options.workflowPath === undefined ? {} : { workflowPath: options.workflowPath }),
        },
      });
      // Headless runs have no reviewer: the sign-off gate is auto-approved
      // (see headlessSignoffChannel) so the single prompt reaches its terminal
      // state and the process exits without waiting on any interaction. The
      // TUI passes its own channel (an overlay on the live TUI) instead.
      const headlessSignoff = headlessSignoffChannel();
      const runPrompt = (
        prompt: string,
        onEvent: (event: AgentEvent) => void,
        signoff: (request: WorkflowSignoffRequest) => Effect.Effect<WorkflowSignoffDecision, WorkflowError> = headlessSignoff,
      ) => {
        const controller = new AbortController();
        activeController = controller;
        // One steering channel per prompt: whichever worker session comes to
        // life during this prompt binds it (harness-side); the TUI pushes
        // mid-turn text through `steerActive` below.
        const steering = createSteeringChannel();
        activeSteering = steering;
        // Pin the run for this prompt's whole lifetime: a `/resume` accepted
        // mid-flight must not redirect a running prompt's evidence.
        const current = active;
        const workflow = loadedWorkflow;
        const events: AgentEvent[] = [];
        // A staging session materialises its run directory here — the first
        // prompt is the moment the run becomes real. Later prompts see a
        // committed session and take the direct path.
        const beginRun = current.commit === undefined
          ? Effect.void
          : current.commit(prompt);
        const persistTrajectory = (document: TrajectoryWriteInput) =>
          current.session.trajectory.write(document).pipe(
            Effect.tapError((error) => Effect.sync(() => {
              // A trajectory is supplementary evidence and must not replace
              // the worker result, but persistence failures must remain
              // visible instead of being silently swallowed.
              stderr.write(`observability write failed: ${error.message}\n`);
            })),
            Effect.ignore,
          );
        /** Fields every turn re-asserts, so the newest values win on resume. */
        const context = {
          promptLength: prompt.length,
          events,
          workspaceCwd: activeCwd,
          ...(workflow === undefined ? {} : { workflowPath: workflow.workflowPath }),
        };
        return TRACE(INPUT_SOURCE, INPUT_LOG.info("input.accepted", {
          data: { promptLength: prompt.length },
        }).pipe(
          Effect.andThen(beginRun),
          Effect.andThen(workflow === undefined
            ? Effect.fail(initialWorkflowFailure ?? new WorkflowError({
              phase: "load",
              path: session.root,
              message: `workflow load failed at ${session.root}: no workflow selected`,
            }))
            // One run is one execution: the run id is the execution id, and each
            // prompt continues the actors the previous prompts left behind. A
            // resumed run therefore takes the identical path as the next prompt
            // of a live run — there is no separate resume mode.
            : readWorkflowExecutionContinuation(current.session.runDir, current.session.id).pipe(
              Effect.flatMap((execution) => executeWorkflow(workflow, {
                runDir: current.session.runDir,
                cwd: activeCwd,
                prompt,
                executionId: current.session.id,
                ...(execution === undefined ? {} : { execution }),
                signal: controller.signal,
                steering,
                ...(options.agentOptions === undefined ? {} : { agentOptions: options.agentOptions }),
                ...(options.agentRunner === undefined ? {} : { agentRunner: options.agentRunner }),
                signoff,
                onEvent: (event) => {
                  events.push(event);
                  onEvent(event);
                },
              })),
            )),
        )).pipe(
          Effect.map((result) => ({
            text: result.text,
            sessionId: result.sessionId,
            transcriptPath: result.transcriptPath,
            trajectoryPath: current.session.trajectory.path,
            progressPath: result.progressPath,
            progressSnapshotPath: result.progressSnapshotPath,
          })),
          Effect.onExit((exit) => Exit.isSuccess(exit)
            ? persistTrajectory({
              ...context,
              prompt,
              status: "completed",
              sessionId: exit.value.sessionId,
              transcriptPath: exit.value.transcriptPath,
            })
            : persistTrajectory({
              ...context,
              prompt,
              status: isCancellation(exit.cause) ? "cancelled" : "failed",
              error: failureDetails(exit.cause),
            })),
          Effect.ensuring(Effect.sync(() => {
            if (activeController === controller) activeController = undefined;
            if (activeSteering === steering) activeSteering = undefined;
          })),
          Effect.provideService(Logging, current.logging),
          Effect.provide(NodeFileSystem.layer),
          // beginRun needs the same services its session commit path uses.
          Effect.provideService(Logging, logging),
        );
      };
      /** `/btw`'s side agent: one direct agent call per prompt, deliberately
       * not a workflow — a side task must not enter the mission's execution,
       * its progress ledger or its stage graph, and one TUI hosting two
       * workflows would make every piece of evidence ambiguous.
       *
       * What it does share with the mission is what the developer expects to be
       * shared: the workspace it edits, the run directory its own harness
       * session files live under, and the interrupt/steering controls (it
       * registers into the same `activeController`/`activeSteering`, so Escape
       * and mid-turn steering work with no extra wiring). It writes no
       * trajectory turn: the run's trajectory is the workflow's evidence, and a
       * side turn replayed as a workflow turn would be a lie. */
      let sideContinuation: AgentContinuation | undefined;
      const runSideAgent = (prompt: string, onEvent: (event: AgentEvent) => void) => {
        const controller = new AbortController();
        activeController = controller;
        const steering = createSteeringChannel();
        activeSteering = steering;
        const current = active;
        const beginRun = current.commit === undefined
          ? Effect.void
          : current.commit(prompt);
        const runAgent = options.agentRunner ?? executeAgent;
        return TRACE(INPUT_SOURCE, INPUT_LOG.info("input.accepted", {
          data: { promptLength: prompt.length, agent: "side" },
        }).pipe(
          Effect.andThen(beginRun),
          // Suspended so the turn reads the continuation left by the previous
          // one: consecutive `/btw` prompts are one conversation.
          Effect.andThen(Effect.suspend(() => runAgent(
            sideAgentRequest({
              prompt,
              cwd: activeCwd,
              runDir: current.session.runDir,
              ...(sideContinuation === undefined ? {} : { continuation: sideContinuation }),
              signal: controller.signal,
              steering,
              onEvent,
            }),
            options.agentOptions ?? {},
          ))),
        )).pipe(
          Effect.tap((result) => Effect.sync(() => {
            sideContinuation = result.continuation;
          })),
          Effect.map((result) => ({
            text: result.text,
            sessionId: result.sessionId,
            transcriptPath: result.transcriptPath,
          })),
          Effect.onExit((exit) => Exit.isSuccess(exit)
            ? INPUT_LOG.info("side.completed", {
              data: { sessionId: exit.value.sessionId, textLength: exit.value.text.length },
            })
            : INPUT_LOG.error("side.failed", {
              data: {
                status: isCancellation(exit.cause) ? "cancelled" : "failed",
                error: failureDetails(exit.cause),
              },
            })),
          Effect.ensuring(Effect.sync(() => {
            if (activeController === controller) activeController = undefined;
            if (activeSteering === steering) activeSteering = undefined;
          })),
          Effect.provideService(Logging, current.logging),
          Effect.provide(NodeFileSystem.layer),
          // beginRun needs the same services its session commit path uses.
          Effect.provideService(Logging, logging),
        );
      };
      if (options.prompt !== undefined) {
        const onEvent = options.json
          ? (event: AgentEvent) => {
              stdout.write(`${serializeLine(agentEventLine(event, session.id))}\n`);
            }
          : () => {};
        const effect = runPrompt(options.prompt, onEvent);
        if (options.json) {
          stdout.write(`${serializeLine(startedLine(session.id, session.cwd))}\n`);
          const result = yield* effect.pipe(
            Effect.onExit((exit) => Effect.sync(() => {
              if (Exit.isSuccess(exit)) {
                stdout.write(`${serializeLine(completedLine(session.id, exit.value))}\n`);
              } else {
                stdout.write(`${serializeLine(failedLine(session.id, "run.failed", failureDetails(exit.cause).message))}\n`);
              }
            })),
          );
          void result;
        } else {
          const result = yield* effect;
          stdout.write(`${result.text}\n`);
        }
      } else {
        let workflowGraph: WorkflowGraphDefinition | undefined;
        if (loadedWorkflow !== undefined) {
          workflowGraph = yield* graphOf(loadedWorkflow).pipe(
            Effect.catchAll((error) => options.workflowPath === undefined
              ? TUI_LOG.warn("tui.workflow_graph_unavailable", {
                data: { error: failureDetails(error) },
              }).pipe(Effect.as(undefined))
              : Effect.fail(error)),
          );
        }
        /** Hand this loop to another run without restarting the process: reopen
         * its session, adopt its workflow and workspace, and hand the TUI the
         * conversation to replay. Nothing else changes — the next prompt goes
         * through the same `runPrompt`, which now sees the resumed run. */
        const resume = (runId: string) => Effect.gen(function* () {
          const context = yield* readResumeContext(runsRoot, runId);
          // `tuna resume <run-id>` already opened the session on this run. Opening
          // a second one would leave two writers appending to the same log and
          // trace files.
          const next = runId === active.session.id
            ? active.session
            : yield* createSession({ cwd: session.cwd, runsRoot, id: runId });
          // A run records the workflow it executed. Reload it so the resumed
          // prompt runs the same stages; keep the current one when the run
          // predates the field or the file has since moved or broken, and say so
          // rather than silently running a different workflow.
          let definition: WorkflowGraphDefinition | undefined;
          let workflowNote: string | undefined;
          if (context.workflowPath === undefined) {
            workflowNote = "this run recorded no workflow; keeping the current one";
          } else {
            const reloaded = yield* loadWorkflow(context.workflowPath, session.root).pipe(
              Effect.flatMap((loaded) => graphOf(loaded).pipe(Effect.map((graph) => ({ loaded, graph })))),
              Effect.either,
            );
            if (reloaded._tag === "Right") {
              loadedWorkflow = reloaded.right.loaded;
              definition = reloaded.right.graph;
            } else {
              workflowNote = `workflow ${context.workflowPath} could not be reloaded; keeping the current one`;
              yield* TUI_LOG.warn("tui.resume_workflow_unavailable", {
                data: { runId, workflowPath: context.workflowPath, error: failureDetails(reloaded.left) },
              });
            }
          }
          active = { session: next, logging: loggingService(next.log, next.trace) };
          activeCwd = context.workspaceCwd ?? next.cwd;
          // A side agent belongs to the run it lives in: after a takeover its
          // next turn starts a fresh conversation under the new run's
          // directory, instead of resuming a transcript filed under the run
          // the TUI just left.
          sideContinuation = undefined;
          yield* TUI_LOG.info("tui.resumed", {
            data: { runId, turns: context.turns.length, ...(workflowNote === undefined ? {} : { note: workflowNote }) },
          });
          return {
            runId,
            turns: context.turns.map((turn) => ({
              prompt: turn.prompt,
              events: turn.events,
              status: turn.status,
              ...(turn.error === undefined ? {} : { error: turn.error }),
            })),
            ...(context.workspaceCwd === undefined ? {} : { workspaceCwd: context.workspaceCwd }),
            ...(definition === undefined ? {} : { workflowGraph: definition }),
            progressSnapshotPath: join(next.runDir, "progress.json"),
          } satisfies TuiResumeResult;
        }).pipe(
          Effect.provide(NodeFileSystem.layer),
          Effect.provideService(Logging, logging),
        );
        const tuiResult = yield* TRACE(TUI_SOURCE, runTui({
          runPrompt,
          runSideAgent,
          historyRoot: session.root,
          workspaceCwd: activeCwd,
          onWorkspaceChange: (cwd) => Effect.sync(() => { activeCwd = cwd; }),
          onWorkflowChange: (workflowPath, builtinName) => loadWorkflow(workflowPath, session.root).pipe(
            Effect.flatMap((nextWorkflow) => graphOf(nextWorkflow).pipe(
              Effect.map((definition) => ({ loaded: nextWorkflow, definition })),
            )),
            Effect.tap(({ loaded }) => Effect.sync(() => { loadedWorkflow = loaded; })),
            // The picker selection is the user's default choice: record it in
            // ~/.tuna/config.json so the next default run starts with it.
            // Builtins are recorded by exact template name, not package path.
            Effect.tap(() => setWorkflowSelection(
              session.root,
              builtinName === undefined ? workflowPath : builtinWorkflowSelection(builtinName),
            )),
            Effect.map(({ definition }) => definition),
            Effect.provide(NodeFileSystem.layer),
            Effect.provideService(Logging, logging),
          ),
          ...(workflowGraph === undefined ? {} : { workflowGraph }),
          progressSnapshotPath: join(session.runDir, "progress.json"),
          ...(options.terminal === undefined ? {} : { terminal: options.terminal }),
          runsRoot,
          currentRunId: session.id,
          onResume: resume,
          ...(options.resumeRunId === undefined ? {} : { resumeRunId: options.resumeRunId }),
          ...(options.resumePicker === true ? { resumePicker: true } : {}),
          onInterrupt: Effect.sync(() => activeController?.abort()),
          // Mid-turn steering: pushes the text into the live prompt's channel.
          // "no-active-turn" (no prompt running, or its backend never bound)
          // tells the TUI to keep queue semantics — the caller never asks
          // which harness is running.
          steerActive: (text) => activeSteering === undefined
            ? Promise.resolve("no-active-turn" as const)
            : activeSteering.steer(text),
          // Renaming targets whichever run the TUI is showing, so it follows a
          // takeover.
          onRename: (name) => active.session.trajectory.rename(name).pipe(
            Effect.provide(NodeFileSystem.layer),
          ),
        }));
        yield* TUI_LOG.info("tui.closed", {
          data: { stalled: tuiResult.stalled === true },
        });
        if (tuiResult.stalled === true) {
          // The TUI handed the terminal back while the interrupted run's
          // finalizers were still wedged — an orphaned harness child or a
          // stuck SDK cleanup can keep the process alive after the exit. The
          // guard guarantees `/exit` ends the process once the evidence on
          // disk has had its drain budget; the shell must never wait on it.
          yield* Effect.sync(() => { armStalledExitGuard(); });
        }
      }
    }));
  }).pipe(
    Effect.provideService(Logging, logging),
    Effect.ensuring(Effect.void),
  );
}

/** Every interactive/headless mission runs against the harness configuration
 * Tuna generates from its own config. Regenerating here, once per mission,
 * is what keeps `resume` and a long-lived session from running on a stale
 * registry after the user edits `~/.tuna/agent.config.json`. */
export function runSession(
  session: Session | StagingSession,
  options: SessionRunOptions,
): Effect.Effect<void, SessionRunError, import("@effect/platform").FileSystem.FileSystem> {
  return prepareHarnessHomes().pipe(
    Effect.flatMap((homes) => runSessionBody(session, {
      ...options,
      agentOptions: {
        ...(options.agentOptions ?? {}),
        ...homes.agentOptions,
        env: {
          ...(options.agentOptions?.env ?? {}),
          ...homes.env,
        },
      },
    })),
  );
}
