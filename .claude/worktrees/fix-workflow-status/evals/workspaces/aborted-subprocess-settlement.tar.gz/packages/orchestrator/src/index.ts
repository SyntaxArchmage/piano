export {
  defaultRoot,
  defaultConfigPath,
  defaultWorkflowTemplatePath,
  defaultRecipeRepositoryRoot,
  recipesDir,
  loadWorkflow,
  loadDefaultWorkflow,
  setWorkflowSelection,
  builtinWorkflowSelection,
  builtinWorkflowSelectionPrefix,
  resolveWorkerResources,
  type LoadedWorkflow,
  type WorkerResources,
} from "./workflow-file.js";
export {
  compileWorkflow,
  PI_WORKFLOW_HARNESS,
  parseWorkflow,
  scheduleWorkflow,
  type CompiledStage,
  type CompiledWorkflow,
  type ScheduledStage,
  type WorkflowDocument,
  type WorkflowHarness,
  type WorkflowLoop,
  type WorkflowNode,
  type WorkflowRegionPlan,
  type WorkflowStage,
  type WorkflowTournament,
} from "./workflow.js";
export {
  admitWinner,
  betterByDirection,
  selectWinner,
  type SelectionAdmission,
  type SelectionBranch,
  type SelectionBranchMetric,
  type SelectionIncumbent,
  type SelectionOutcome,
  type SelectionReferee,
  type SelectionRejection,
} from "./selection.js";
export { WorkflowError, type WorkflowPhase } from "./errors.js";
export {
  allocateMapWorkspace,
  cleanupMapWorkspaces,
  recoverMapWorkspaces,
  sharedWorkspaceBinding,
  type WorkflowCarrying,
  type WorkflowCarryKind,
  type WorkflowWorkspaceBinding,
  type WorkflowWorkspaceCleanupOptions,
  type WorkflowWorkspaceRecord,
  type WorkflowWorkspacePhase,
  type WorkflowWorkspaceStatus,
  type WorkflowWorkspaceStrategy,
} from "./workspace.js";
/**
 * @deprecated Direct winner application and whole-tree comparison are retained
 * for callers of the pre-tournament workspace API. Automatic tournament
 * execution goes through `consolidateAndGate` and the shared consolidation
 * transaction instead.
 */
export {
  applyWinnerWorkspace,
  diffWorkspaceContent,
  type WorkspaceContentDiff,
} from "./workspace.js";
export {
  consolidateAndGate,
  executeWorkflow,
  loadAndExecuteWorkflow,
  VALIDATE_REPAIR_ATTEMPTS,
  type LoadAndExecuteWorkflowRequest,
  type WorkflowExecutionRequest,
  type WorkflowExecutionResult,
  type WorkflowStageExecutionResult,
  type WorkflowExecutionError,
  type WorkflowSignoffDecision,
  type WorkflowSignoffRequest,
  type WorkflowWorkspaceCandidate,
  type WorkflowWorkspaceLifecycleOptions,
  type WorkflowWorkspaceSelectionContext,
  type WorkflowWorkspaceWinner,
} from "./workflow-execution.js";
export {
  ConsolidationEvidencePreparationError,
  prepareConsolidationEvidence,
  runConsolidationTransaction,
  type ConsolidationCarrying,
  type ConsolidationDirectoryIdentity,
  type ConsolidationEvidenceInput,
  type ConsolidationTransactionInput,
  type PreparedConsolidationEvidence,
} from "./consolidation-transaction.js";
export {
  readWorkflowExecutionContinuation,
  type WorkflowActorContinuation,
  type WorkflowExecutionContinuation,
} from "./workflow-resume.js";
export {
  appendWorkflowProgress,
  finalizeWorkflowProgress,
  initializeWorkflowProgress,
  markWorkflowStageStarted,
  workflowProgressPath,
  workflowProgressSnapshotPath,
  type WorkflowProgressRecord,
  type WorkflowProgressCurrent,
  type WorkflowProgressPlan,
  type WorkflowProgressProjection,
  type WorkflowProgressSnapshot,
  type WorkflowProgressStageCount,
} from "./progress.js";
export {
  snapshotWorkerContract,
  type WorkerContractReference,
} from "./contract-snapshot.js";
export {
  buildCommitMessage,
  commitRoundFiles,
  extractTicket,
  safeChangedFiles,
  snapshotDirtyFiles,
  type WinnerCommitMessage,
  type WinnerCommitMessageInput,
} from "./winner-commit.js";
